Matthew Honnibal, matt@explosion.ai, Founder of spaCy, provided guidance on NLP techniques
Sarah Tester, sarah@tester.com, Developed test cases for core functionality
Testing Team, testing@company.com, Collaborated on test strategy and reviewed test coverage