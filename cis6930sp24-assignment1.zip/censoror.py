import argparse
import os
import re
import json
from collections import defaultdict
import spacy
import sys
import warnings 
import glob
import pytest

# Load the SpaCy English language model
# nlp = spacy.load("en_core_web_sm")
try:
    nlp = spacy.load("en_core_web_md")
except IOError:
    print("SpaCy model not found. Downloading...")
    spacy.cli.download("en_core_web_md")
    nlp = spacy.load("en_core_web_md")

# Define a function to read input documents
def read_files_from_patterns(patterns):
    documents = {}
    for pattern in patterns:
        for path in glob.glob(pattern):
            with open(path, 'r', encoding='utf-8') as file:
                documents[path] = file.read()
    return documents

# Define functions to detect sensitive information using SpaCy NER
def detect_names(text):
    doc = nlp(text)
    return [ent.text for ent in doc.ents if ent.label_ == "PERSON"]

# Define functions to detect sensitive information using regular expressions
def detect_dates(text):
    return re.findall(r'\b\d{1,2}/\d{1,2}/\d{2,4}\b', text)

def detect_phones(text):
    return re.findall(r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', text)

def detect_addresses(text):
    return re.findall(r'\b\d{1,5}\s\w+\s\w+\b', text)

# Define a function to censor sensitive information
def censor(text, sensitive_info):
    for info in sensitive_info:
        text = text.replace(info, '█' * len(info))
    return text

# Define a function to write censored documents to the output directory
def write_censored_documents(output_dir, documents):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    for filename, content in documents.items():
        with open(os.path.join(output_dir, os.path.basename(filename) + ".censored"), 'w', encoding='utf-8') as file:
            file.write(content)

# Define a function to generate statistics
def generate_statistics(censored_documents, stats_output):
    stats = defaultdict(int)
    for content in censored_documents.values():
        for term in content.split():
            stats[term] += 1
    with open(stats_output, 'w') as file:
        json.dump(stats, file)

warnings.filterwarnings("ignore", category=UserWarning)

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Censor sensitive information from text documents")
    parser.add_argument("--input", nargs="+", help="Input file(s)")
    parser.add_argument("--output", help="Output directory for censored documents")
    parser.add_argument("--names", action="store_true", help="Detect and censor names")
    parser.add_argument("--dates", action="store_true", help="Detect and censor dates")
    parser.add_argument("--phones", action="store_true", help="Detect and censor phone numbers")
    parser.add_argument("--address", action="store_true", help="Detect and censor addresses")
    parser.add_argument("--stats", help="Output file for statistics")
    args = parser.parse_args()

    # Check if required arguments are provided
    if not args.input or not args.output or not any([args.names, args.dates, args.phones, args.address]) or not args.stats:
        print("Usage: pipenv run python censoror.py --input '*.txt' --names --dates --phones --address --output 'files/' --stats stderr")
        sys.exit(1)

    # Read input documents
    documents = read_files_from_patterns(args.input)

    # Detect and censor sensitive information
    censored_documents = {}
    for filename, content in documents.items():
        censored_content = content
        if args.names:
            names = detect_names(content)
            censored_content = censor(censored_content, names)
        if args.dates:
            dates = detect_dates(content)
            censored_content = censor(censored_content, dates)
        if args.phones:
            phones = detect_phones(content)
            censored_content = censor(censored_content, phones)
        if args.address:
            addresses = detect_addresses(content)
            censored_content = censor(censored_content, addresses)
        censored_documents[filename] = censored_content

    # Write censored documents to the output directory
    write_censored_documents(args.output, censored_documents)

    # Generate statistics
    generate_statistics(censored_documents, args.stats)

if __name__ == "__main__":
    main()
