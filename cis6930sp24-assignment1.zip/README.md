PROJECT OVERVIEW

The project "The Censoror" is a comprehensive initiative aimed at automating the labor-intensive process of redacting sensitive information within plain text documents such as police reports and medical records. By leveraging a sophisticated data pipeline system, it targets the identification and replacement of sensitive entities like names, dates, phone numbers, and addresses with designated characters. The system stores the redacted files systematically in a user-specified directory, thereby optimizing efficiency and ensuring compliance with privacy standards. Through the integration of advanced detection mechanisms and character replacement techniques, "The Censoror" endeavors to enhance the speed and accuracy of the redaction process, ultimately facilitating the seamless management of sensitive information across diverse document types.

RUNNING INSTRUCTIONS

To execute the "Censoror" program, ensure Pipenv and Python are installed, then access the project repository. From the terminal, navigate to the project's root directory and run the command: `pipenv run python censoror.py --input '*.txt' --names --dates --phones --address --output 'files/' --stats stderr`. This command processes all .txt files in the current folder, censoring names, dates, phone numbers, and addresses. Censored files, with .censored extensions, are stored in the specified 'files/' directory, while statistics on the censorship process are written to the standard error output. Be meticulous in executing the program with the appropriate parameters to accurately detect and redact sensitive information.

BUGS AND ASSUMPTION

Bugs:
The code lacks robust error handling for scenarios such as failure in loading the SpaCy model or encountering issues during file operations like reading input files or writing censored documents. While error messages are displayed for some exceptions, the program continues execution without addressing the underlying issues, potentially leading to crashes or unexpected behavior.

Assumptions:
The program assumes that input files are in plain text format with the .txt extension and that the SpaCy model "en_core_web_md" is accessible for loading or can be downloaded seamlessly. It also assumes the accuracy and comprehensiveness of the sensitive information detection methods provided. Furthermore, the code assumes the existence of the specified output directory for censored documents and relies on users to provide valid input parameters through the command line. These assumptions, if not met, may result in incomplete or inaccurate censoring processes and hinder the program's functionality.


Function Fetch/download:
read_documents(input_glob):

Description:The `read_documents` function serves to ingest and parse input files specified by the user, organizing them into a dictionary structure where each file's name is associated with its corresponding content. Utilizing a provided list of file paths or glob patterns, the function iterates through each file, reading its contents and storing them in memory. By employing a dictionary data structure, the function ensures efficient access to file contents during subsequent processing stages. This function operates with the presumption that the input files are readable and exist in the specified locations. However, it lacks error handling mechanisms to address potential issues such as inaccessible files or unsupported file formats. Therefore, while the `read_documents` function effectively gathers input data for further processing, it would benefit from additional robustness features to enhance its reliability in diverse runtime environments.
Parameters:
input_glob: List of input file paths or glob patterns.
Returns: A dictionary where keys are file names and values are the content of the corresponding files.


PARSE/EXTRACT
detect_names(text):

Description: Detects names using SpaCy Named Entity Recognition (NER).
Parameters:
text: Plain text to detect names from.
Returns: A list of detected names.
detect_dates(text):

Description: Detects dates using regular expressions.
Parameters:
text: Plain text to detect dates from.
Returns: A list of detected dates in the format (DD/MM/YYYY).
detect_phones(text):

Description: Detects phone numbers using regular expressions.
Parameters:
text: Plain text to detect phone numbers from.
Returns: A list of detected phone numbers.
detect_addresses(text):

Description: Detects addresses using regular expressions.
Parameters:
text: Plain text to detect addresses from.
Returns: A list of detected addresses.

FUNCTION CREATE
write_censored_documents(output_dir, documents):

Description: The write_censored_documents function is responsible for saving censored documents to the specified output directory. It first checks if the output directory exists; if not, it creates the directory recursively using os.makedirs().

POPULATE/INSERT
write_censored_documents(output_dir, documents):

Description: Writes censored documents to the output directory.it iterates through the documents dictionary, which contains filenames as keys and their corresponding censored content as values. For each document, the function opens a new file in the output directory with a ".censored" extension appended to the original filename. It writes the censored content to the file using the write() method. This function ensures that censored documents are appropriately stored in the designated output directory for further use or distribution.
Parameters:
output_dir: Directory path where censored documents will be saved.
documents: Dictionary containing file names as keys and censored content as values.
Returns: None.

STATUS/PRINT
generate_statistics(censored_documents, stats_output):

Description: The `generate_statistics` function calculates term frequency statistics from censored documents and writes them to the specified output file. It iterates through the censored documents, tallying the frequency of each term. The resulting statistics are then stored in JSON format in the designated output file. This function offers insights into term distribution within the censored documents.
Parameters:
censored_documents: Dictionary containing censored content of documents.
stats_output: File path where statistics will be saved.
Returns: None.

Test Functions:

test_names.py
A unit test case function used to test names being censored 

test_phones.py
A unit test case function used to test phones being censored 

test_address.py
A unit test case function used to test address being censored 