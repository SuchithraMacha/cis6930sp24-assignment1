import unittest
import os
import tempfile
import json
from collections import defaultdict
import sys 

sys.path.append("../")

from censoror import (
    read_documents,
    detect_names,
    detect_dates,
    detect_phones,
    detect_addresses,
    censor,
    write_censored_documents,
    generate_statistics,
)

class TestCensorFunctions(unittest.TestCase):

    def setUp(self):
        self.input_filenames = ['testInput1.txt', 'testInput2.txt']  # Adjusted filenames
        self.input_contents = ['John Doe was born on 12/25/1990. His phone number is (123) 456-7890. He lives at 123 Main St.',
                               'Mary Smith was born on 05/10/1985. Her phone number is (987) 654-3210. She lives at 456 Elm St.']
        self.censored_names = ['John Doe', 'Mary Smith']
        self.censored_dates = ['12/25/1990', '05/10/1985']
        self.censored_phones = ['(123) 456-7890', '(987) 654-3210']
        self.censored_addresses = ['123 Main St.', '456 Elm St.']

        # Create temporary directory for test files
        self.tmp_dir = tempfile.mkdtemp()

        # Create temporary input files
        for filename, content in zip(self.input_filenames, self.input_contents):
            filepath = os.path.join(self.tmp_dir, filename)
            with open(filepath, 'w') as f:
                f.write(content)

    def tearDown(self):
        # Remove temporary input files
        for filename in self.input_filenames:
            filepath = os.path.join(self.tmp_dir, filename)
            os.remove(filepath)

    def test_read_documents(self):
        file_paths = [filename for filename in self.input_filenames]
        documents = read_documents(file_paths)
        self.assertEqual(len(documents), 2)
        for filename in self.input_filenames:
            basename = os.path.basename(filename)
            self.assertIn(basename, documents)
        
            # Open the test input file and read its content
            with open(filename, 'r') as file:
                expected_content = file.read()
        
            self.assertEqual(documents[basename], expected_content)


    def test_detect_names(self):
        for i, content in enumerate(self.input_contents):
            names = detect_names(content)
            self.assertIn(self.censored_names[i], names)

    def test_detect_dates(self):
        for i, content in enumerate(self.input_contents):
            dates = detect_dates(content)
            self.assertIn(self.censored_dates[i], dates)

    def test_detect_phones(self):
        for i, content in enumerate(self.input_contents):
            phones = detect_phones(content)
            self.assertIn(self.censored_phones[i], phones)

    def test_censor(self):
        text = 'John Doe was born on 12/25/1990. His phone number is (123) 456-7890. He lives at 123 Main St.'
        censored_text = censor(text, ['John Doe', '12/25/1990', '(123) 456-7890', '123 Main St.'])
        expected_text = censored_text
        self.assertEqual(censored_text, expected_text)

    def test_write_censored_documents(self):
        censored_documents = {'testInput1.txt': 'Censored content 1', 'testInput2.txt': 'Censored content 2'}  # Adjusted filenames
        output_dir = self.tmp_dir
        write_censored_documents(output_dir, censored_documents)
        for filename, content in censored_documents.items():
            output_file = os.path.join(output_dir, filename + '.censored')
            self.assertTrue(os.path.exists(output_file))
            with open(output_file, 'r') as f:
                self.assertEqual(f.read(), content)

if __name__ == '__main__':
    unittest.main()
